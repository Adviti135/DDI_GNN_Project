"""
=============================================================================
MEMBER C — STEP 2: Temporal Co-Prescription Edge Simulation
=============================================================================
Role: Clinician / Domain Expert
Task: Simulate realistic temporal co-prescription sequences for validated
      DDI pairs. Output tensor-ready temporal edge dataset.

Clinical basis for temporal simulation:
  - Drug prescriptions follow realistic clinical patterns
  - High-severity DDIs tend to co-occur in acute/complex patients
  - Chronic disease drugs (statins, antihypertensives) have long overlap durations
  - Antibiotic courses are short (7–14 days)
  - Temporal patterns affect DDI risk (e.g., cumulative toxicity builds over time)

OUTPUT FILES:
  temporal_edges.csv     : all temporal co-prescription edges
  temporal_edges.npz     : numpy arrays for Member A (tensor-ready)
  temporal_summary.txt   : description of temporal simulation

Run: python step2_temporal_edges.py
  (Requires step1 to have been run first)
=============================================================================
"""

import pandas as pd
import numpy as np
import json
import random
import os

random.seed(42)
np.random.seed(42)

OUT = os.path.dirname(os.path.abspath(__file__))

# Load validated DDI pairs from Step 1
validated_df = pd.read_csv(f"{OUT}/ddi_validated.csv")
drug_df = pd.read_csv(f"{OUT}/drugs.csv")
drug_id_map = dict(zip(drug_df["drug_name"], drug_df["drug_id"]))
n_drugs = len(drug_df)

# ─────────────────────────────────────────────────────────────────────────────
# CLINICAL DURATION PROFILES
# Prescription duration varies by drug class — used to assign realistic
# co-prescription window lengths
# ─────────────────────────────────────────────────────────────────────────────

DURATION_PROFILES = {
    "anticoagulant":     ("chronic",   90, 365),   # (type, min_days, max_days)
    "antiplatelet":      ("chronic",   90, 365),
    "statin":            ("chronic",  180, 730),
    "antibiotic":        ("acute",      7,  14),
    "antidepressant":    ("chronic",   90, 365),
    "maoi":              ("chronic",   60, 365),
    "antihypertensive":  ("chronic",  180, 730),
    "ppi":               ("variable",  14, 180),
    "nsaid":             ("acute",      5,  30),
    "diabetes":          ("chronic",  180, 730),
    "antifungal":        ("acute",      7,  30),
    "antiepileptic":     ("chronic",  180, 730),
    "immunosuppressant": ("chronic",  180, 730),
    "opioid":            ("acute",      3,  30),
    "antipsychotic":     ("chronic",   90, 365),
    "other":             ("variable",  14, 180),
}

def get_duration(drug_class):
    profile = DURATION_PROFILES.get(drug_class, DURATION_PROFILES["other"])
    return random.randint(profile[1], profile[2])

# ─────────────────────────────────────────────────────────────────────────────
# SIMULATE PATIENT TIMELINES
# Each "patient" has a series of drug prescriptions with timestamps.
# DDI pairs appear together in the same patient's prescription window.
# ─────────────────────────────────────────────────────────────────────────────

print("Simulating patient prescription timelines...")

N_PATIENTS = 500
DAYS_RANGE = 730  # 2-year observation window

# Build drug class lookup
drug_class_map = dict(zip(drug_df["drug_name"], drug_df["drug_class"]))

temporal_records = []
patient_prescriptions = {}

# Simulate patient timelines
for patient_id in range(N_PATIENTS):
    # Assign 2–8 drugs per patient (polypharmacy)
    n_drugs_for_patient = random.randint(2, 8)
    patient_drugs = random.sample(list(drug_id_map.keys()), n_drugs_for_patient)

    prescriptions = []
    for drug in patient_drugs:
        drug_class = drug_class_map.get(drug, "other")
        start_day = random.randint(0, DAYS_RANGE - 30)
        duration = get_duration(drug_class)
        end_day = min(start_day + duration, DAYS_RANGE)
        prescriptions.append({
            "patient_id": patient_id,
            "drug": drug,
            "drug_id": drug_id_map[drug],
            "start_day": start_day,
            "end_day": end_day,
            "duration_days": end_day - start_day,
            "drug_class": drug_class,
        })
    patient_prescriptions[patient_id] = prescriptions

# ─────────────────────────────────────────────────────────────────────────────
# EXTRACT TEMPORAL EDGES
# A temporal edge (drug_a, drug_b, t) exists when:
#   - Two drugs co-occur in the same patient's prescription window
#   - The overlap window >= 1 day
# ─────────────────────────────────────────────────────────────────────────────

print("Extracting temporal co-prescription edges...")

# Load validated DDI pairs to flag known interactions
validated_pairs = set()
for _, row in validated_df.iterrows():
    validated_pairs.add((row["drug_a"], row["drug_b"]))
    validated_pairs.add((row["drug_b"], row["drug_a"]))

# DDI severity lookup
severity_map = {}
for _, row in validated_df.iterrows():
    severity_map[(row["drug_a"], row["drug_b"])] = row.get("severity_int", 0)
    severity_map[(row["drug_b"], row["drug_a"])] = row.get("severity_int", 0)

edge_records = []
seen_edges = {}  # (drug_a_id, drug_b_id, time_bucket) → count

for patient_id, prescriptions in patient_prescriptions.items():
    for i, rx_a in enumerate(prescriptions):
        for j, rx_b in enumerate(prescriptions):
            if j <= i:
                continue

            # Check for temporal overlap
            overlap_start = max(rx_a["start_day"], rx_b["start_day"])
            overlap_end   = min(rx_a["end_day"],   rx_b["end_day"])

            if overlap_end - overlap_start < 1:
                continue  # no co-prescription overlap

            # Temporal features
            drug_a, drug_b = rx_a["drug"], rx_b["drug"]
            da_id, db_id = rx_a["drug_id"], rx_b["drug_id"]

            # Canonical ordering (lower id first)
            if da_id > db_id:
                drug_a, drug_b = drug_b, drug_a
                da_id, db_id = db_id, da_id
                rx_a, rx_b = rx_b, rx_a

            is_ddi = 1 if (drug_a, drug_b) in validated_pairs or (drug_b, drug_a) in validated_pairs else 0
            sev = severity_map.get((drug_a, drug_b), severity_map.get((drug_b, drug_a), 0))

            # Time bucket (week of overlap start) — coarse temporal discretization
            time_bucket = overlap_start // 7

            edge_records.append({
                "patient_id":      patient_id,
                "drug_a":          drug_a,
                "drug_b":          drug_b,
                "drug_a_id":       da_id,
                "drug_b_id":       db_id,
                "t_start":         overlap_start,     # day of co-prescription start
                "t_end":           overlap_end,
                "overlap_days":    overlap_end - overlap_start,
                "time_bucket":     time_bucket,        # weekly bin for temporal GNN
                "rx_a_start":      rx_a["start_day"],  # individual prescription starts
                "rx_b_start":      rx_b["start_day"],
                "delta_start_days":abs(rx_a["start_day"] - rx_b["start_day"]),  # sequential gap
                "is_ddi":          is_ddi,
                "severity_int":    sev,
            })

temporal_df = pd.DataFrame(edge_records)
temporal_df = temporal_df.drop_duplicates(subset=["drug_a_id","drug_b_id","time_bucket","patient_id"])
temporal_df.to_csv(f"{OUT}/temporal_edges.csv", index=False)

print(f"  Total temporal edges:         {len(temporal_df)}")
print(f"  Edges with known DDI:         {temporal_df['is_ddi'].sum()}")
print(f"  Unique drug pairs (temporal): {temporal_df[['drug_a_id','drug_b_id']].drop_duplicates().shape[0]}")
print(f"  Patients with co-prescriptions: {temporal_df['patient_id'].nunique()}")

# ─────────────────────────────────────────────────────────────────────────────
# EXPORT TENSOR-READY ARRAYS FOR MEMBER A
# ─────────────────────────────────────────────────────────────────────────────

print("\nExporting tensor-ready numpy arrays...")

# Edge index (2 x E): [source_nodes, target_nodes]
src = temporal_df["drug_a_id"].values
dst = temporal_df["drug_b_id"].values
edge_index = np.stack([src, dst], axis=0)  # shape (2, E)

# Edge attributes: [overlap_days, delta_start_days, time_bucket, severity_int]
edge_attr = temporal_df[[
    "overlap_days", "delta_start_days", "time_bucket", "severity_int"
]].values.astype(np.float32)

# Temporal timestamps (normalised to [0,1])
timestamps = (temporal_df["t_start"].values / DAYS_RANGE).astype(np.float32)

# Labels
labels = temporal_df["is_ddi"].values.astype(np.int64)

# Node features (drug molecular features) — first 20 fingerprint bits + pharmacokinetics
fp_cols = [f"fp_{i}" for i in range(20)]
pk_cols = ["half_life_h", "protein_binding", "bioavailability",
           "cyp3a4_substrate","cyp2c9_substrate","cyp2c19_substrate","cyp2d6_substrate"]
feature_cols = fp_cols + pk_cols
node_features = drug_df[feature_cols].values.astype(np.float32)

# Normalise continuous features
for col_idx, col in enumerate(feature_cols):
    col_data = node_features[:, col_idx]
    col_max = col_data.max()
    if col_max > 0:
        node_features[:, col_idx] = col_data / col_max

np.savez(
    f"{OUT}/temporal_edges.npz",
    edge_index=edge_index,
    edge_attr=edge_attr,
    timestamps=timestamps,
    labels=labels,
    node_features=node_features,
)

print(f"  edge_index shape:    {edge_index.shape}")
print(f"  edge_attr shape:     {edge_attr.shape}")
print(f"  timestamps shape:    {timestamps.shape}")
print(f"  labels shape:        {labels.shape}")
print(f"  node_features shape: {node_features.shape}")

# ─────────────────────────────────────────────────────────────────────────────
# SUMMARY
# ─────────────────────────────────────────────────────────────────────────────

summary = f"""
========================================================
  MEMBER C — TEMPORAL EDGE SIMULATION REPORT
========================================================
Clinical Basis:
  - {N_PATIENTS} synthetic patients simulated over {DAYS_RANGE}-day window
  - Drug prescription durations modelled by class:
      Chronic drugs (statins, antihypertensives): 180–730 days
      Acute drugs (antibiotics, NSAIDs): 5–30 days
      Variable drugs (PPIs, antifungals): 14–180 days
  - Co-prescription = temporal overlap ≥ 1 day

Temporal Edge Statistics:
  Total co-prescription edges:    {len(temporal_df)}
  Edges flagged as DDI positive:  {temporal_df['is_ddi'].sum()}
  Unique drug pairs:              {temporal_df[['drug_a_id','drug_b_id']].drop_duplicates().shape[0]}
  Patients with edges:            {temporal_df['patient_id'].nunique()}
  Mean overlap duration (days):   {temporal_df['overlap_days'].mean():.1f}
  Max overlap duration (days):    {temporal_df['overlap_days'].max()}

Tensor Shapes (→ Member A):
  edge_index:    {edge_index.shape}   (2 × E, LongTensor)
  edge_attr:     {edge_attr.shape}    (E × 4, FloatTensor)
  timestamps:    {timestamps.shape}   (E,   FloatTensor, normalised)
  labels:        {labels.shape}       (E,   LongTensor)
  node_features: {node_features.shape} (N × {node_features.shape[1]}, FloatTensor)

Edge Attribute Columns (order in edge_attr):
  [0] overlap_days       — duration of co-prescription window
  [1] delta_start_days   — gap between prescription start dates
  [2] time_bucket        — weekly bin (for T-GNN time encoding)
  [3] severity_int       — DDI severity (0=none,1=minor,2=mod,3=major)

Assumption Notes (for paper Limitations):
  - All timestamps are synthetic; no real EHR data used
  - Patient timelines do not include comorbidities or demographics
  - Drug-drug overlap does not account for dose adjustments
  - Temporal ordering is random; no causal prescription logic applied

Output files:
  temporal_edges.csv     — full edge table (human-readable)
  temporal_edges.npz     — numpy arrays (model-ready)
========================================================
"""
print(summary)
with open(f"{OUT}/temporal_summary.txt", "w") as f:
    f.write(summary)

print("Done.")
