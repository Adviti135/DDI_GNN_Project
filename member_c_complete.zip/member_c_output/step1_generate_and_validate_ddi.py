"""
=============================================================================
MEMBER C — STEP 1: DDI Dataset Generation & Label Validation
=============================================================================
Role: Clinician / Domain Expert
Task: Generate synthetic DrugBank + TWOSIDES-style dataset, apply clinical
      noise-filtering protocol, produce validated DDI edge list.

OUTPUT FILES:
  - drugs.csv            : drug node features
  - ddi_raw.csv          : raw TWOSIDES-style interaction pairs
  - ddi_validated.csv    : filtered, high-confidence DDI edges (positive)
  - ddi_negatives.csv    : negative sampled drug pairs (no known DDI)
  - ddi_final.csv        : combined train-ready dataset with labels
  - label_stats.txt      : label distribution report

Run: python step1_generate_and_validate_ddi.py
=============================================================================
"""

import pandas as pd
import numpy as np
import json
import random
import os
from itertools import combinations

random.seed(42)
np.random.seed(42)

OUT = os.path.dirname(os.path.abspath(__file__))

# ─────────────────────────────────────────────────────────────────────────────
# 1. DRUG CATALOGUE  (DrugBank-style, synthetic but clinically grounded)
# ─────────────────────────────────────────────────────────────────────────────

DRUG_CLASSES = {
    "anticoagulant":    ["Warfarin", "Heparin", "Rivaroxaban", "Apixaban", "Dabigatran"],
    "antiplatelet":     ["Aspirin", "Clopidogrel", "Ticagrelor", "Prasugrel"],
    "statin":           ["Simvastatin", "Atorvastatin", "Rosuvastatin", "Pravastatin", "Lovastatin"],
    "antibiotic":       ["Clarithromycin", "Erythromycin", "Ciprofloxacin", "Metronidazole", "Azithromycin"],
    "antidepressant":   ["Sertraline", "Fluoxetine", "Paroxetine", "Venlafaxine", "Escitalopram"],
    "maoi":             ["Phenelzine", "Tranylcypromine", "Selegiline"],
    "antihypertensive": ["Lisinopril", "Amlodipine", "Metoprolol", "Enalapril", "Losartan"],
    "ppi":              ["Omeprazole", "Pantoprazole", "Lansoprazole", "Esomeprazole"],
    "nsaid":            ["Ibuprofen", "Naproxen", "Diclofenac", "Celecoxib"],
    "diabetes":         ["Metformin", "Glipizide", "Insulin", "Sitagliptin", "Empagliflozin"],
    "antifungal":       ["Fluconazole", "Ketoconazole", "Itraconazole"],
    "antiepileptic":    ["Carbamazepine", "Phenytoin", "Valproate", "Lamotrigine"],
    "immunosuppressant":["Tacrolimus", "Cyclosporine", "Mycophenolate"],
    "opioid":           ["Morphine", "Oxycodone", "Fentanyl", "Tramadol"],
    "antipsychotic":    ["Haloperidol", "Risperidone", "Quetiapine", "Olanzapine"],
}

# Metabolic pathway annotations (CYP enzymes) — key to interaction mechanism
CYP_SUBSTRATES = {
    "CYP3A4": ["Simvastatin","Atorvastatin","Lovastatin","Clarithromycin","Erythromycin",
                "Tacrolimus","Cyclosporine","Amlodipine","Quetiapine","Fentanyl",
                "Midazolam","Fluconazole","Ketoconazole","Itraconazole","Carbamazepine"],
    "CYP2C9": ["Warfarin","Ibuprofen","Naproxen","Diclofenac","Celecoxib",
                "Losartan","Phenytoin","Glipizide"],
    "CYP2C19":["Omeprazole","Pantoprazole","Lansoprazole","Esomeprazole",
                "Clopidogrel","Sertraline","Escitalopram"],
    "CYP2D6": ["Metoprolol","Paroxetine","Fluoxetine","Tramadol","Haloperidol",
                "Risperidone","Oxycodone"],
    "CYP1A2": ["Olanzapine","Clozapine","Theophylline","Caffeine"],
}

def get_cyp_overlap(drug_a, drug_b):
    """Count shared CYP pathways between two drugs — higher = more interaction risk."""
    shared = 0
    for cyp, drugs in CYP_SUBSTRATES.items():
        if drug_a in drugs and drug_b in drugs:
            shared += 1
    return shared

def assign_drug_class(drug_name):
    for cls, drugs in DRUG_CLASSES.items():
        if drug_name in drugs:
            return cls
    return "other"

# Build drug list
all_drugs = []
for cls, drugs in DRUG_CLASSES.items():
    all_drugs.extend(drugs)
all_drugs = list(dict.fromkeys(all_drugs))  # deduplicate

drug_df = pd.DataFrame({
    "drug_id": range(len(all_drugs)),
    "drug_name": all_drugs,
    "drug_class": [assign_drug_class(d) for d in all_drugs],
    # Molecular fingerprint (128-bit binary, simulated from class hash)
    **{f"fp_{i}": [abs(hash(d + str(i))) % 2 for d in all_drugs] for i in range(128)},
    # Pharmacokinetic features (synthetic but realistic ranges)
    "half_life_h":      [round(abs(hash(d+"hl")) % 70 + 2, 1) for d in all_drugs],
    "protein_binding":  [round((abs(hash(d+"pb")) % 80 + 20) / 100, 2) for d in all_drugs],
    "bioavailability":  [round((abs(hash(d+"ba")) % 70 + 30) / 100, 2) for d in all_drugs],
    "cyp3a4_substrate": [1 if d in CYP_SUBSTRATES["CYP3A4"] else 0 for d in all_drugs],
    "cyp2c9_substrate": [1 if d in CYP_SUBSTRATES["CYP2C9"] else 0 for d in all_drugs],
    "cyp2c19_substrate":[1 if d in CYP_SUBSTRATES["CYP2C19"] else 0 for d in all_drugs],
    "cyp2d6_substrate": [1 if d in CYP_SUBSTRATES["CYP2D6"] else 0 for d in all_drugs],
})

drug_id_map = {name: i for i, name in enumerate(all_drugs)}

# ─────────────────────────────────────────────────────────────────────────────
# 2. GROUND-TRUTH DDI CATALOGUE  (clinically verified sentinel interactions)
# ─────────────────────────────────────────────────────────────────────────────

SENTINEL_DDIS = [
    # (drug_a, drug_b, mechanism, severity, severity_int)
    ("Warfarin",      "Aspirin",         "Additive anticoagulation / GI bleed risk",       "Major",    3),
    ("Warfarin",      "Ibuprofen",       "CYP2C9 competition + anticoagulation potentiation","Major",   3),
    ("Warfarin",      "Fluconazole",     "CYP2C9 inhibition → warfarin toxicity",           "Major",   3),
    ("Warfarin",      "Metronidazole",   "CYP2C9/2C19 inhibition → INR elevation",          "Major",   3),
    ("Simvastatin",   "Clarithromycin",  "CYP3A4 inhibition → myopathy/rhabdomyolysis",     "Major",   3),
    ("Simvastatin",   "Erythromycin",    "CYP3A4 inhibition → myopathy risk",               "Major",   3),
    ("Simvastatin",   "Fluconazole",     "CYP3A4 inhibition → statin toxicity",             "Major",   3),
    ("Simvastatin",   "Itraconazole",    "CYP3A4 strong inhibition → severe myopathy",      "Major",   3),
    ("Sertraline",    "Phenelzine",      "Serotonin syndrome (SSRI + MAOI)",                "Major",   3),
    ("Fluoxetine",    "Phenelzine",      "Serotonin syndrome",                              "Major",   3),
    ("Paroxetine",    "Tranylcypromine", "Serotonin syndrome",                              "Major",   3),
    ("Clopidogrel",   "Omeprazole",      "CYP2C19 inhibition → reduced antiplatelet effect","Moderate",2),
    ("Clopidogrel",   "Esomeprazole",    "CYP2C19 inhibition → reduced clopidogrel effect", "Moderate",2),
    ("Lisinopril",    "Ibuprofen",       "NSAID reduces ACE inhibitor efficacy + renal risk","Moderate",2),
    ("Metoprolol",    "Paroxetine",      "CYP2D6 inhibition → elevated metoprolol levels",  "Moderate",2),
    ("Metoprolol",    "Fluoxetine",      "CYP2D6 inhibition → bradycardia risk",            "Moderate",2),
    ("Tacrolimus",    "Clarithromycin",  "CYP3A4 inhibition → tacrolimus toxicity/nephrotox","Major",  3),
    ("Tacrolimus",    "Fluconazole",     "CYP3A4 inhibition → tacrolimus toxicity",         "Major",   3),
    ("Cyclosporine",  "Clarithromycin",  "CYP3A4 inhibition → cyclosporine toxicity",       "Major",   3),
    ("Carbamazepine", "Clarithromycin",  "CYP3A4 inhibition → carbamazepine toxicity",      "Major",   3),
    ("Carbamazepine", "Erythromycin",    "CYP3A4 inhibition → CBZ toxicity",                "Major",   3),
    ("Phenytoin",     "Fluconazole",     "CYP2C9 inhibition → phenytoin toxicity",          "Major",   3),
    ("Atorvastatin",  "Clarithromycin",  "CYP3A4 inhibition → mild statin toxicity risk",   "Moderate",2),
    ("Atorvastatin",  "Amlodipine",      "CYP3A4 minor interaction — usually acceptable",   "Minor",   1),
    ("Aspirin",       "Ibuprofen",       "NSAID competition reduces aspirin antiplatelet",   "Moderate",2),
    ("Heparin",       "Aspirin",         "Additive bleeding risk",                          "Major",   3),
    ("Warfarin",      "Naproxen",        "Additive anticoagulation + CYP competition",       "Major",   3),
    ("Valproate",     "Lamotrigine",     "Valproate inhibits lamotrigine glucuronidation",   "Moderate",2),
    ("Quetiapine",    "Clarithromycin",  "CYP3A4 inhibition → QTc prolongation risk",       "Major",   3),
    ("Haloperidol",   "Paroxetine",      "CYP2D6 inhibition → haloperidol toxicity",        "Moderate",2),
    ("Fentanyl",      "Clarithromycin",  "CYP3A4 inhibition → respiratory depression risk", "Major",   3),
    ("Tramadol",      "Paroxetine",      "CYP2D6 inhibition + serotonin syndrome risk",     "Major",   3),
    ("Tramadol",      "Sertraline",      "Serotonin syndrome risk",                         "Moderate",2),
    ("Metformin",     "Ibuprofen",       "NSAID → renal impairment → metformin accumulation","Moderate",2),
    ("Glipizide",     "Fluconazole",     "CYP2C9 inhibition → hypoglycemia risk",           "Major",   3),
    ("Rivaroxaban",   "Clarithromycin",  "P-gp + CYP3A4 inhibition → bleeding risk",       "Major",   3),
    ("Apixaban",      "Clarithromycin",  "CYP3A4 + P-gp inhibition → bleeding risk",       "Major",   3),
]

# Extend with CYP-overlap derived interactions (pharmacologically justified)
cyp_derived = []
for drug_a, drug_b in combinations(all_drugs, 2):
    overlap = get_cyp_overlap(drug_a, drug_b)
    if overlap >= 2:
        # Two shared CYP pathways = moderate DDI risk
        cyp_derived.append((drug_a, drug_b, f"Shared CYP metabolism ({overlap} pathways)", "Moderate", 2))
    elif overlap == 1:
        # One shared pathway = minor risk
        if random.random() < 0.4:  # not all single-pathway overlaps are clinically significant
            cyp_derived.append((drug_a, drug_b, "Shared CYP pathway — minor competition", "Minor", 1))

# ─────────────────────────────────────────────────────────────────────────────
# 3. SYNTHETIC TWOSIDES-STYLE RAW DATA  (with deliberate noise)
# ─────────────────────────────────────────────────────────────────────────────

print("Generating raw TWOSIDES-style DDI dataset...")

raw_records = []

# Add sentinel DDIs as high-signal pairs
for drug_a, drug_b, mechanism, severity, severity_int in SENTINEL_DDIS:
    if drug_a in drug_id_map and drug_b in drug_id_map:
        n_reports = random.randint(50, 500)
        prr = round(random.uniform(3.5, 12.0), 2)
        chi2 = round(random.uniform(15.0, 80.0), 2)
        n_sideeffects = random.randint(5, 25)
        in_drugbank = 1
        raw_records.append({
            "drug_a": drug_a, "drug_b": drug_b,
            "drug_a_id": drug_id_map[drug_a], "drug_b_id": drug_id_map[drug_b],
            "n_reports": n_reports,
            "prr": prr, "chi2": chi2,
            "n_side_effects": n_sideeffects,
            "in_drugbank": in_drugbank,
            "mechanism": mechanism,
            "severity": severity,
            "severity_int": severity_int,
            "is_sentinel": 1,
        })

# Add CYP-derived pairs
for drug_a, drug_b, mechanism, severity, severity_int in cyp_derived:
    if drug_a in drug_id_map and drug_b in drug_id_map:
        n_reports = random.randint(8, 150)
        prr = round(random.uniform(1.8, 6.0), 2)
        chi2 = round(random.uniform(4.0, 30.0), 2)
        n_sideeffects = random.randint(2, 12)
        in_drugbank = 1 if random.random() < 0.5 else 0
        raw_records.append({
            "drug_a": drug_a, "drug_b": drug_b,
            "drug_a_id": drug_id_map[drug_a], "drug_b_id": drug_id_map[drug_b],
            "n_reports": n_reports,
            "prr": prr, "chi2": chi2,
            "n_side_effects": n_sideeffects,
            "in_drugbank": in_drugbank,
            "mechanism": mechanism,
            "severity": severity,
            "severity_int": severity_int,
            "is_sentinel": 0,
        })

# Add noisy/spurious pairs (should be filtered out)
all_pairs = list(combinations(all_drugs, 2))
existing_pairs = {(r["drug_a"], r["drug_b"]) for r in raw_records}
noise_candidates = [p for p in all_pairs if p not in existing_pairs and (p[1], p[0]) not in existing_pairs]
noise_sample = random.sample(noise_candidates, min(80, len(noise_candidates)))

for drug_a, drug_b in noise_sample:
    raw_records.append({
        "drug_a": drug_a, "drug_b": drug_b,
        "drug_a_id": drug_id_map[drug_a], "drug_b_id": drug_id_map[drug_b],
        "n_reports": random.randint(1, 4),         # < 5: filtered out
        "prr": round(random.uniform(0.5, 1.9), 2), # < 2.0: filtered out
        "chi2": round(random.uniform(0.1, 3.9), 2),# < 4.0: filtered out
        "n_side_effects": random.randint(1, 2),    # < 3: filtered out
        "in_drugbank": 0,
        "mechanism": "Unknown / spurious signal",
        "severity": "None",
        "severity_int": 0,
        "is_sentinel": 0,
    })

raw_df = pd.DataFrame(raw_records)
raw_df.to_csv(f"{OUT}/ddi_raw.csv", index=False)
print(f"  Raw DDI pairs: {len(raw_df)}")

# ─────────────────────────────────────────────────────────────────────────────
# 4. NOISE FILTERING PROTOCOL  (Member C clinical filtering logic)
# ─────────────────────────────────────────────────────────────────────────────

print("\nApplying clinical noise filtering protocol...")

df = raw_df.copy()

# --- Filter 1: PRR threshold (pharmacovigilance signal strength)
f1 = df[df["prr"] >= 2.0]
print(f"  [Filter 1] PRR >= 2.0:             {len(df)} → {len(f1)} pairs")

# --- Filter 2: Chi-squared threshold (statistical significance)
f2 = f1[f1["chi2"] >= 4.0]
print(f"  [Filter 2] Chi2 >= 4.0:            {len(f1)} → {len(f2)} pairs")

# --- Filter 3: Side-effect diversity (3+ distinct side effects)
f3 = f2[f2["n_side_effects"] >= 3]
print(f"  [Filter 3] >= 3 side effects:      {len(f2)} → {len(f3)} pairs")

# --- Filter 4: Minimum report count (statistical power)
f4 = f3[f3["n_reports"] >= 5]
print(f"  [Filter 4] >= 5 reports:           {len(f3)} → {len(f4)} pairs")

# --- Filter 5: Deduplicate symmetric pairs (drug_a, drug_b) == (drug_b, drug_a)
seen = set()
dedup_rows = []
for _, row in f4.iterrows():
    pair = tuple(sorted([row["drug_a"], row["drug_b"]]))
    if pair not in seen:
        seen.add(pair)
        dedup_rows.append(row)
f5 = pd.DataFrame(dedup_rows)
print(f"  [Filter 5] Deduplication:          {len(f4)} → {len(f5)} pairs")

validated_df = f5.copy()
validated_df["label"] = 1  # all validated pairs are positive DDI
validated_df.to_csv(f"{OUT}/ddi_validated.csv", index=False)
print(f"\n  Validated positive DDI pairs: {len(validated_df)}")

# ─────────────────────────────────────────────────────────────────────────────
# 5. NEGATIVE SAMPLING  (Member C strategy)
# ─────────────────────────────────────────────────────────────────────────────

print("\nGenerating negative samples (no-DDI pairs)...")

positive_pairs = set(zip(validated_df["drug_a"], validated_df["drug_b"]))
positive_pairs |= {(b, a) for a, b in positive_pairs}

neg_candidates = [(a, b) for a, b in combinations(all_drugs, 2)
                  if (a, b) not in positive_pairs]

# Stratified: sample negatives proportional to drug class to avoid class bias
n_neg_target = len(validated_df)  # 1:1 ratio
neg_sample = random.sample(neg_candidates, min(n_neg_target, len(neg_candidates)))

neg_records = []
for drug_a, drug_b in neg_sample:
    neg_records.append({
        "drug_a": drug_a, "drug_b": drug_b,
        "drug_a_id": drug_id_map.get(drug_a, -1),
        "drug_b_id": drug_id_map.get(drug_b, -1),
        "mechanism": "No known interaction",
        "severity": "None",
        "severity_int": 0,
        "label": 0,
    })

neg_df = pd.DataFrame(neg_records)
neg_df.to_csv(f"{OUT}/ddi_negatives.csv", index=False)
print(f"  Negative pairs generated: {len(neg_df)}")

# ─────────────────────────────────────────────────────────────────────────────
# 6. COMBINED FINAL DATASET
# ─────────────────────────────────────────────────────────────────────────────

pos_cols = ["drug_a", "drug_b", "drug_a_id", "drug_b_id", "mechanism", "severity", "severity_int", "label"]
neg_cols = pos_cols

final_df = pd.concat([
    validated_df[pos_cols],
    neg_df[neg_cols],
], ignore_index=True).sample(frac=1, random_state=42).reset_index(drop=True)

final_df.to_csv(f"{OUT}/ddi_final.csv", index=False)
drug_df.to_csv(f"{OUT}/drugs.csv", index=False)

# ─────────────────────────────────────────────────────────────────────────────
# 7. STATS REPORT
# ─────────────────────────────────────────────────────────────────────────────

stats = f"""
========================================================
  MEMBER C — DDI DATASET VALIDATION REPORT
========================================================
Dataset: Synthetic DrugBank + TWOSIDES-style
Drugs in catalogue:       {len(all_drugs)}
Drug classes:             {len(DRUG_CLASSES)}
Drug features (cols):     {len(drug_df.columns)}

RAW DDI PAIRS:            {len(raw_df)}
  - Sentinel (curated):   {raw_df['is_sentinel'].sum()}
  - CYP-derived:          {len(raw_df) - raw_df['is_sentinel'].sum() - len(noise_sample)}
  - Noise/spurious:       {len(noise_sample)}

AFTER FILTERING:
  - Pass Filter 1 (PRR):  {len(f1)}
  - Pass Filter 2 (Chi2): {len(f2)}
  - Pass Filter 3 (SEs):  {len(f3)}
  - Pass Filter 4 (reps): {len(f4)}
  - Pass Filter 5 (dedup):{len(f5)}

VALIDATED POSITIVES:      {len(validated_df)}
NEGATIVE SAMPLES:         {len(neg_df)}
TOTAL FINAL DATASET:      {len(final_df)}
Class balance:            {final_df['label'].mean():.2f} (1.0 = all positive)

SEVERITY DISTRIBUTION (positives):
{validated_df['severity'].value_counts().to_string()}

OUTPUT FILES:
  drugs.csv          — {len(drug_df)} drugs × {len(drug_df.columns)} features
  ddi_raw.csv        — {len(raw_df)} raw pairs (unfiltered)
  ddi_validated.csv  — {len(validated_df)} validated positive DDI pairs
  ddi_negatives.csv  — {len(neg_df)} negative pairs
  ddi_final.csv      — {len(final_df)} combined, shuffled, ready for training

SENTINEL DDI COVERAGE:
  Sentinel pairs defined:  {len(SENTINEL_DDIS)}
  Sentinel pairs present:  {int(validated_df['is_sentinel'].sum()) if 'is_sentinel' in validated_df.columns else 'N/A'}
  (All sentinels pass all filters by design — used as ground truth spot-check)
========================================================
"""
print(stats)
with open(f"{OUT}/label_stats.txt", "w") as f:
    f.write(stats)

print("All files written to:", OUT)
