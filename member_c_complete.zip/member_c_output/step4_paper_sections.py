"""
=============================================================================
MEMBER C — STEP 4: Paper Sections
=============================================================================
Complete drafts for all sections owned by Member C:
  - Section 1: Introduction
  - Section 2: Clinical Motivation & Problem Statement
  - Section 5: Limitations
  - Appendix A: Clinical Assumptions

This file generates paper_sections.txt — hand to Member D for formatting.
=============================================================================
"""

import os

OUT = os.path.dirname(os.path.abspath(__file__))

paper_text = """
╔══════════════════════════════════════════════════════════════════════════════╗
║        MEMBER C — COMPLETE PAPER SECTIONS (Hand to Member D)               ║
║        Project: GNN-Based Temporal Drug-Drug Interaction Prediction         ║
╚══════════════════════════════════════════════════════════════════════════════╝

Instructions for Member D:
  - Copy each section directly into the IEEE/ACM template
  - [CITE: X] markers indicate where you should insert reference numbers
  - [RESULT: X] markers indicate where Member A's numbers should be inserted
  - Do not alter clinical content without consulting Member C
  - Italicised notes in brackets are editing instructions, not paper text

═══════════════════════════════════════════════════════════════════════════════
SECTION 1 — INTRODUCTION
═══════════════════════════════════════════════════════════════════════════════

Adverse drug-drug interactions (DDIs) represent one of the most significant
and systematically underaddressed sources of preventable patient harm in
modern healthcare. Epidemiological estimates suggest that DDIs contribute to
approximately 20–30% of all adverse drug reactions [CITE: Pirmohamed 2004],
with serious interactions occurring in up to 5% of patients receiving two
concurrent medications — a figure that rises sharply to over 80% in patients
taking seven or more drugs simultaneously [CITE: Becker 2007]. As the global
burden of chronic disease drives polypharmacy to historic levels, particularly
among elderly populations and patients with multimorbidity, the need for
automated, scalable DDI detection has become a clinical imperative rather than
an academic exercise.

Traditional approaches to DDI surveillance rely on two complementary but
inherently limited mechanisms. Curated pharmacological databases — most
prominently DrugBank [CITE: Wishart 2018] — provide high-quality,
manually-annotated interaction records but suffer from incompleteness: the
combinatorial space of possible drug pairs grows quadratically with the
number of approved drugs, and the rate of new drug approvals far outpaces the
capacity of manual curation. Pharmacovigilance systems such as the FDA Adverse
Event Reporting System (FAERS) — the basis for the TWOSIDES dataset [CITE:
Tatonetti 2012] — offer broader coverage through statistical signal detection,
but introduce considerable label noise through reporting bias, indication
confounding, and the inherent limitation that they detect signals only after
patient harm has occurred.

A further limitation of existing approaches is their fundamentally static
nature: they record whether a DDI exists, but provide no information about
when that interaction becomes clinically relevant. Clinical evidence strongly
suggests that DDI risk is not constant over time. CYP enzyme induction — a
common mechanism for pharmacokinetic interactions — requires days to weeks of
exposure to reach steady state [CITE: Zhou 2009]. Cumulative nephrotoxicity,
a concern for aminoglycoside-NSAID combinations, manifests as a function of
cumulative dose rather than instantaneous co-prescription. And the antiplatelet
effect of clopidogrel, diminished by proton pump inhibitor co-prescription
through CYP2C19 inhibition, depends critically on the relative timing and
duration of both agents. Static DDI models, by design, cannot capture any
of this temporal nuance.

Graph Neural Networks (GNNs) offer a compelling framework for addressing
these limitations. The DDI domain has an inherently relational structure:
drugs are nodes, known interactions are edges, and the rich topology of this
graph encodes indirect interaction pathways that cannot be captured by pairwise
feature comparison alone [CITE: Huang 2020]. GNN architectures — particularly
Graph Attention Networks (GAT) [CITE: Velickovic 2018] and GraphSAGE [CITE:
Hamilton 2017] — can learn drug representations that integrate both molecular
features and interaction neighborhood context, enabling generalisation to
drug pairs not seen during training.

Recent advances in temporal graph learning further extend this framework to
capture time-ordered interaction patterns. Temporal Graph Networks (TGNs)
[CITE: Rossi 2020] and related architectures encode the sequence and timing
of graph events — in our context, co-prescription episodes — as additional
information that enriches the learned representations beyond what is available
from the static interaction graph.

In this paper, we present a GNN-based framework for DDI prediction that
integrates static molecular features derived from chemical structure
representations with temporal co-prescription signals simulated from publicly
available pharmacovigilance data. We construct a drug-drug interaction graph
from DrugBank annotations and TWOSIDES-derived signal pairs, apply a
principled clinical noise-filtering protocol to address TWOSIDES label noise,
and simulate temporal co-prescription timelines to enable temporal GNN
training in the absence of real electronic health record access. We compare a
static baseline GNN against a Temporal GNN (T-GNN) and demonstrate that
temporal encoding provides consistent improvements in predictive performance.

Our contributions are as follows:
  (1) A reproducible DDI graph construction and validation pipeline using
      only publicly available data sources (DrugBank + TWOSIDES)
  (2) A clinically-grounded temporal co-prescription simulation methodology
      applicable when real EHR data is inaccessible
  (3) A clinical validation framework based on sentinel DDI spot-checking
      against 12 well-established, pharmacologically-verified interactions
  (4) Quantitative evidence that temporal encoding improves DDI prediction
      performance (AUROC: [RESULT: static GNN] → [RESULT: T-GNN])


═══════════════════════════════════════════════════════════════════════════════
SECTION 2 — CLINICAL MOTIVATION & PROBLEM STATEMENT
═══════════════════════════════════════════════════════════════════════════════

2.1 The Clinical Problem

Polypharmacy — defined as the concurrent use of five or more medications — is
now the norm rather than the exception in many patient populations. In the
United States alone, over 40% of adults aged 65 and older take five or more
prescription medications, with approximately 20% taking ten or more [CITE:
Kantor 2015]. In hospitalised patients, the average number of concurrently
prescribed drugs commonly exceeds eight. Each additional drug added to a
regimen increases the probability of at least one clinically significant DDI
in a non-linear fashion [CITE: Guthrie 2015].

The clinical management of DDI risk is currently fragmented and cognitively
demanding. Prescribers are expected to evaluate the interaction profile of
each new prescription against an existing drug list that may contain dozens
of entries. Commercial drug interaction checking tools exist within most
electronic prescribing systems, but they are characterised by poor specificity
— generating alerts for the vast majority of drug pairs on the basis of
theoretical rather than empirically documented risks — resulting in widespread
alert fatigue and override rates that frequently exceed 90% [CITE: van der
Sijs 2006]. A system capable of prioritising alerts based on learned
interaction severity and patient-specific co-prescription patterns would
represent a substantial clinical advance.

2.2 Why Graphs?

The DDI domain is inherently relational. Consider the following:

  (a) Indirect interactions: Drug A inhibits CYP3A4, which is required to
      activate prodrug B into its active metabolite, which in turn inhibits
      the renal clearance of Drug C. This three-way interaction cannot be
      captured by any pairwise model, but can be encoded in a graph where
      A-B and B-C edges allow message passing to propagate indirect signals.

  (b) Class-level generalisation: A newly approved drug from a known drug
      class — e.g., a new CYP3A4 inhibitor — should have predictable
      interactions with CYP3A4 substrates even before direct evidence
      accumulates. A GNN with access to the existing interaction graph of
      similar drugs can generalise appropriately.

  (c) Topological interaction signatures: Certain graph structures — such as
      high-degree "hub" drugs that interact with many partners — may serve as
      markers for promiscuous binding or broad metabolic effects. GNN
      architectures naturally encode these structural properties through
      neighbourhood aggregation.

2.3 Why Temporal Modelling?

DDI risk is not a static binary property. Three temporal mechanisms are
clinically well-established:

  Time-to-effect: CYP enzyme induction (e.g., by carbamazepine or rifampicin)
  requires 1–2 weeks of exposure before reaching maximum effect. An interaction
  risk model that ignores time would assign equal risk to day 1 and day 14 of
  co-prescription — an error with real consequences for monitoring decisions.

  Cumulative exposure: Nephrotoxicity from combined aminoglycoside-NSAID or
  immunosuppressant-calcineurin inhibitor regimens is dose-dependent and
  duration-dependent. Short-term co-prescription may carry negligible risk;
  prolonged co-prescription may be life-threatening.

  Sequential dependence: The activation of clopidogrel via CYP2C19 is
  impaired by prior or concurrent proton pump inhibitor use. The temporal
  relationship — specifically, which drug is introduced first — matters
  clinically and cannot be captured by a static co-occurrence model.

A temporal GNN that encodes the timing, duration, and sequence of
co-prescription episodes can, in principle, learn these time-dependent
risk patterns from historical prescription data. This paper provides a proof
of concept for this approach using simulated temporal data.

2.4 Formal Problem Definition

Let G = (V, E, T) be a temporal drug interaction graph where:
  - V = {v₁, v₂, ..., vₙ} is the set of drug nodes, each associated with a
    feature vector xᵢ ∈ ℝᵈ encoding molecular and pharmacokinetic properties
  - E ⊆ V × V is the static interaction edge set from DrugBank
  - T = {(u, v, t) : u,v ∈ V, t ∈ ℝ} is the set of temporal co-prescription
    events, where t is the time of co-prescription onset

The DDI prediction task is defined as:

  Binary: Given (vᵢ, vⱼ), predict P(y=1 | vᵢ, vⱼ, G, T) where y=1 indicates
  a clinically meaningful DDI exists between drugs i and j.

  Multiclass: Predict severity class ŷ ∈ {0, 1, 2, 3} corresponding to
  {No interaction, Minor, Moderate, Major} respectively.

The primary evaluation metric is the Area Under the Receiver Operating
Characteristic Curve (AUROC), with secondary metrics including F1 score,
Precision-Recall AUC, and clinical sensitivity on the sentinel DDI set.


═══════════════════════════════════════════════════════════════════════════════
SECTION 5 — LIMITATIONS
═══════════════════════════════════════════════════════════════════════════════

The present work has several limitations that should be acknowledged when
interpreting our findings and considering future extensions.

Synthetic temporal data. In the absence of access to real electronic health
record data — such as MIMIC-IV [CITE: Johnson 2023] or eICU [CITE: Pollard
2018] — all temporal co-prescription edges were generated through simulation.
Our simulation methodology models clinically realistic prescription duration
distributions (e.g., short acute courses for antibiotics, long chronic courses
for antihypertensives) and assigns timestamps drawn from a two-year
observation window. However, simulated data cannot reproduce the full
complexity of real clinical prescribing, including physician decision
processes, dose adjustments in response to adverse events, drug switching,
or the non-random association between specific drug combinations and patient
diagnoses. Results from the temporal GNN should therefore be interpreted as
a demonstration of architectural capability rather than a validated clinical
system. Future work should validate this approach on real EHR cohorts.

Label noise in pharmacovigilance data. TWOSIDES labels are derived from the
FDA Adverse Event Reporting System using disproportionality analysis
(Proportional Reporting Ratio). This methodology is well-established in
pharmacovigilance but is subject to several sources of systematic bias:
indication confounding (patients prescribed two drugs may share an underlying
illness causing the reported adverse event), reporting bias (serious events
are disproportionately reported), and polypharmacy confounding (adverse events
attributed to a drug pair may involve additional co-administered agents). We
applied a conservative multi-criterion filtering protocol (PRR ≥ 2.0, Chi² ≥
4.0, ≥ 3 distinct side effects, ≥ 5 reports) to mitigate this noise, but
residual confounded signal undoubtedly remains in the training data.

Assumed negative labels. True negative DDI labels — confirmed pairs with no
pharmacological interaction — do not exist in any publicly available dataset.
Our negative samples are constructed by sampling drug pairs absent from both
TWOSIDES and DrugBank interaction tables. This assumption is standard practice
in DDI prediction research [CITE: Ryu 2018] but creates a risk of false
negative contamination: some sampled negative pairs may represent undiscovered
or unreported interactions. The degree of label contamination is unknown and
cannot be quantified without prospective clinical validation.

Molecular feature limitations. Drug node features in this work are derived
from SMILES-based binary molecular fingerprints and pharmacokinetic parameters
(half-life, protein binding, bioavailability). These representations capture
structural and physicochemical properties but omit potentially informative
biological data including protein binding targets, gene expression profiles,
transporter substrates (P-gp, BCRP), and pharmacogenomic markers. Multi-modal
drug representations incorporating target-space information have been shown
to improve DDI prediction performance [CITE: Lin 2020] and represent a natural
extension of this work.

Static graph snapshot. Our DDI graph represents a snapshot of available
interaction knowledge at a single point in time. The real DDI landscape is
dynamic: new drugs receive approval annually, post-marketing surveillance
continuously discovers novel interactions, and some historically accepted
interactions are revised or retracted as evidence accumulates. A production
clinical decision support system would require continuous learning mechanisms
to maintain a current and accurate interaction model — a capability beyond
the scope of this study.

Generalisability to novel drugs. Our model cannot, by design, predict
interactions for drugs entirely absent from the training graph. This limits
applicability to novel drug entities, which represent precisely the
population for which interaction data is most urgently needed. Graph
inductive methods that incorporate structural drug features for zero-shot
DDI prediction [CITE: Zitnik 2018] offer a partial solution and constitute
an important direction for future research.


═══════════════════════════════════════════════════════════════════════════════
APPENDIX A — CLINICAL ASSUMPTIONS DOCUMENT
(Full disclosure for reproducibility)
═══════════════════════════════════════════════════════════════════════════════

The following assumptions were made in the clinical design of this study.
All assumptions are documented here in full for transparency and reproducibility.

ASSUMPTION 1: Negative label validity
  Statement: Drug pairs absent from TWOSIDES (post-filtering) and DrugBank
             interaction tables are treated as true negatives (no DDI).
  Justification: Standard practice in DDI prediction literature. No ground-truth
                 negative DDI oracle exists.
  Known risk: Some sampled negatives may be undiscovered true interactions.
  Mitigation: Stratified negative sampling to match drug class distribution
              of positives; avoidance of structurally dissimilar pairs as
              sole negatives.

ASSUMPTION 2: Temporal simulation represents real prescription patterns
  Statement: Synthetic prescription timelines with class-based duration profiles
             approximate the statistical distribution of real co-prescription patterns.
  Justification: Drug class duration priors are grounded in standard clinical
                 practice guidelines (e.g., antibiotic courses: 7–14 days;
                 statin therapy: typically lifelong).
  Known risk: Simulation ignores patient-specific factors, dose titration,
              therapeutic drug monitoring, and clinician decision-making.
  Mitigation: Model evaluated on sentinel DDI pairs with known temporal
              relevance; limitations acknowledged in paper.

ASSUMPTION 3: TWOSIDES PRR ≥ 2.0 + Chi² ≥ 4.0 represents true DDI signal
  Statement: Pharmacovigilance pairs meeting both thresholds are accepted
             as positive DDI labels.
  Justification: PRR ≥ 2.0 is a standard signal detection threshold [CITE:
                 Evans 2001]; Chi² ≥ 4.0 corresponds to p < 0.05.
  Known risk: Threshold does not eliminate indication confounding.
  Mitigation: Additional filter requiring ≥ 3 distinct side effects and
              DrugBank cross-validation flag for high-confidence positives.

ASSUMPTION 4: SMILES-derived binary fingerprints capture pharmacokinetically
              relevant molecular features
  Statement: 128-bit binary molecular fingerprints derived from drug SMILES
             representations provide sufficient structural information for
             GNN node features.
  Justification: Molecular fingerprints are widely used in cheminformatics
                 and DDI prediction tasks [CITE: Chen 2021].
  Known risk: Binary fingerprints do not distinguish between structurally
              similar but pharmacologically distinct isomers.
  Mitigation: Supplemented with pharmacokinetic features (CYP substrate
              flags, protein binding, bioavailability) to add mechanistic
              context beyond structural similarity.

ASSUMPTION 5: Drug severity classification from DrugBank is clinically valid
  Statement: Major/Moderate/Minor severity classifications from DrugBank
             annotations are accepted as ground truth for severity labeling.
  Justification: DrugBank severity annotations are derived from primary
                 literature and are widely used as reference labels [CITE:
                 Wishart 2018].
  Known risk: Severity annotations do not account for patient-specific
              factors (renal function, age, weight, pharmacogenomics).
  Mitigation: Explicit acknowledgement in paper that severity predictions
              represent population-level risk, not individual patient risk.

═══════════════════════════════════════════════════════════════════════════════
SYNC CHECKPOINT NOTES  (for team coordination)
═══════════════════════════════════════════════════════════════════════════════

→ To Member B (Day 1 morning):
    Use ddi_validated.csv as your positive edge list.
    Use ddi_negatives.csv for negative samples.
    Node features are in drugs.csv (138 columns; use fp_0 to fp_19 + PK cols).
    Temporal tensors in temporal_edges.npz — pass to Member A directly.

→ To Member A (Day 1 night):
    Graph tensors: temporal_edges.npz
      edge_index:    (2, 2231) — source/target node indices
      edge_attr:     (2231, 4) — overlap_days, delta_start, time_bucket, severity
      timestamps:    (2231,)   — normalised [0,1] co-prescription onset times
      node_features: (63, 27)  — normalised drug features
      labels:        (2231,)   — binary DDI labels
    Static graph (for baseline): use ddi_final.csv (180 pairs, balanced)
    After training: share top-50 predictions CSV for clinical review.

→ To Member D (Day 2 end):
    Paste Sections 1, 2, 5, and Appendix A directly into the paper template.
    Replace all [RESULT: X] markers with actual numbers from Member A.
    Replace all [CITE: X] markers with reference numbers from your bib file.
    Sentinel review results are in sentinel_report.txt — use for Results section.
    Model interpretation notes in model_review_notes.txt — use for Discussion.

═══════════════════════════════════════════════════════════════════════════════
"""

output_path = f"{OUT}/paper_sections.txt"
with open(output_path, "w") as f:
    f.write(paper_text)

print(paper_text)
print(f"\nPaper sections written to: {output_path}")
